package ch.ibw.leistnachweis1;


/**
 * @author Nett HansJ�rg
 *
 */
public class Dividend {

	public static void main(String[] args) {
		int a = 5;
		double b = 6;
		double result = a/b;
		
		System.out.println(result);
	}

}
