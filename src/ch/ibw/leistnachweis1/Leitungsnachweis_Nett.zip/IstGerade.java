
package ch.ibw.leistnachweis1;

/**
 * @author Nett Hans Juerg
 *
 */
public class IstGerade {

	public static void main(String[] args) {
		int zahl = 3;
		
		if((zahl % 2) == 0){
			System.out.println("Gerade");
		}
		else{
			System.out.println("Ungerade");
		}

	}

}
