
package ch.ibw.leistnachweis1;

/**
 * @author Nett HansJ�rg
 *
 */
public class ShortCalculation {

	public static void main(String[] args) {
		short a = 5;
		short b = 6;
		short result = (short) (a + b);

		System.out.println(result);
	}

}
