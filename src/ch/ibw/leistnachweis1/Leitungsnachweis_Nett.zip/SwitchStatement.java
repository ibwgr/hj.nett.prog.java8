
package ch.ibw.leistnachweis1;

/**
 * @author Nett Hans-Juerg
 *
 */
public class SwitchStatement {

	public static void main(String[] args) {
		
		int note = 3;
		
		if(note < 4){
			System.out.println("Ungen�gend");
		}
		else{
			System.out.println("Bestanden");
		}
	}

}
